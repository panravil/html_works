
		var myFullpage = new fullpage('#fullpage', {
		anchors: ['firstPage', 'secondPage', '3rdPage'],
			css3: true
		});
		var htmlc = ['1 Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vestibulum fermentum tortor id mi. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Maecenas libero. Integer tempor. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Maecenas sollicitudin. Suspendisse nisl. Etiam egestas wisi a erat. Donec iaculis gravida nulla. Duis condimentum augue id magna semper rutrum. Etiam neque. Sed convallis magna eu sem. Nam libero tempore, cum soluta ',
			'2 Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vestibulum fermentum tortor id mi. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Maecenas libero. Integer tempor. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Maecenas sollicitudin. Suspendisse nisl. Etiam egestas wisi a erat. Donec iaculis gravida nulla. Duis condimentum augue id magna semper rutrum. Etiam neque. Sed convallis magna eu sem. Nam libero tempore, cum soluta ',
			'3 Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vestibulum fermentum tortor id mi. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Maecenas libero. Integer tempor. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Maecenas sollicitudin. Suspendisse nisl. Etiam egestas wisi a erat. Donec iaculis gravida nulla. Duis condimentum augue id magna semper rutrum. Etiam neque. Sed convallis magna eu sem. Nam libero tempore, cum soluta ',
			'4 Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vestibulum fermentum tortor id mi. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Maecenas libero. Integer tempor. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Maecenas sollicitudin. Suspendisse nisl. Etiam egestas wisi a erat. Donec iaculis gravida nulla. Duis condimentum augue id magna semper rutrum. Etiam neque. Sed convallis magna eu sem. Nam libero tempore, cum soluta ',
			'5 Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vestibulum fermentum tortor id mi. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Maecenas libero. Integer tempor. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Maecenas sollicitudin. Suspendisse nisl. Etiam egestas wisi a erat. Donec iaculis gravida nulla. Duis condimentum augue id magna semper rutrum. Etiam neque. Sed convallis magna eu sem. Nam libero tempore, cum soluta ',
			'6 Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vestibulum fermentum tortor id mi. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Maecenas libero. Integer tempor. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Maecenas sollicitudin. Suspendisse nisl. Etiam egestas wisi a erat. Donec iaculis gravida nulla. Duis condimentum augue id magna semper rutrum. Etiam neque. Sed convallis magna eu sem. Nam libero tempore, cum soluta ',
			'7 Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vestibulum fermentum tortor id mi. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Maecenas libero. Integer tempor. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Maecenas sollicitudin. Suspendisse nisl. Etiam egestas wisi a erat. Donec iaculis gravida nulla. Duis condimentum augue id magna semper rutrum. Etiam neque. Sed convallis magna eu sem. Nam libero tempore, cum soluta ',
			'8 Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vestibulum fermentum tortor id mi. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Maecenas libero. Integer tempor. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Maecenas sollicitudin. Suspendisse nisl. Etiam egestas wisi a erat. Donec iaculis gravida nulla. Duis condimentum augue id magna semper rutrum. Etiam neque. Sed convallis magna eu sem. Nam libero tempore, cum soluta ',
			'9 Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vestibulum fermentum tortor id mi. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Maecenas libero. Integer tempor. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Maecenas sollicitudin. Suspendisse nisl. Etiam egestas wisi a erat. Donec iaculis gravida nulla. Duis condimentum augue id magna semper rutrum. Etiam neque. Sed convallis magna eu sem. Nam libero tempore, cum soluta ',
			'0 Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vestibulum fermentum tortor id mi. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Maecenas libero. Integer tempor. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Maecenas sollicitudin. Suspendisse nisl. Etiam egestas wisi a erat. Donec iaculis gravida nulla. Duis condimentum augue id magna semper rutrum. Etiam neque. Sed convallis magna eu sem. Nam libero tempore, cum soluta ',
			'1 Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vestibulum fermentum tortor id mi. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Maecenas libero. Integer tempor. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Maecenas sollicitudin. Suspendisse nisl. Etiam egestas wisi a erat. Donec iaculis gravida nulla. Duis condimentum augue id magna semper rutrum. Etiam neque. Sed convallis magna eu sem. Nam libero tempore, cum soluta ',
			'2 Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vestibulum fermentum tortor id mi. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Maecenas libero. Integer tempor. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Maecenas sollicitudin. Suspendisse nisl. Etiam egestas wisi a erat. Donec iaculis gravida nulla. Duis condimentum augue id magna semper rutrum. Etiam neque. Sed convallis magna eu sem. Nam libero tempore, cum soluta ',
			'3 Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vestibulum fermentum tortor id mi. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Maecenas libero. Integer tempor. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Maecenas sollicitudin. Suspendisse nisl. Etiam egestas wisi a erat. Donec iaculis gravida nulla. Duis condimentum augue id magna semper rutrum. Etiam neque. Sed convallis magna eu sem. Nam libero tempore, cum soluta ',
			'4 Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vestibulum fermentum tortor id mi. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Maecenas libero. Integer tempor. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Maecenas sollicitudin. Suspendisse nisl. Etiam egestas wisi a erat. Donec iaculis gravida nulla. Duis condimentum augue id magna semper rutrum. Etiam neque. Sed convallis magna eu sem. Nam libero tempore, cum soluta '
		];

		$(document).on('mouseover', '.title-list-c li', function(){
			var list_c = $('.title-list-c').children('li');
			list_c.each(function () {
				$(this).removeClass('selected');
			});
			$(this).addClass('selected');
			t = $(this).text();
			$(this).closest('.content-text-c').find('.text-title').text(t);

			idx = $('.left-side').find('.selected').index();
			len = list_c.length;
			percent = idx / ( len - 1 ) * 91;

			cont = htmlc[idx];
			$(this).closest('.content-text-c').find('.text-cont').text(cont);

			$('.div-btn').css('top', percent+'%');

		});


		$(document).on('click', '.title-list-c li', function(){
			var list_c = $('.title-list-c').children('li');
			list_c.each(function () {
				$(this).removeClass('selected');
			});
			$(this).addClass('selected');
			t = $(this).text();
			$(this).closest('.content-text-c').find('.text-title').text(t);

			idx = $('.left-side').find('.selected').index();
			len = list_c.length;
			percent = idx / ( len - 1 ) * 91;

			cont = htmlc[idx];
			$(this).closest('.content-text-c').find('.text-cont').text(cont);

			$('.div-btn').css('top', percent+'%');

		});